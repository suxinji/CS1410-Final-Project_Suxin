import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.List;
/**
 * @author Suxin Ji
 *
 */
public class Bullet extends Object implements Constant {
	 //This class is used to create a bullet for the tank. It inherits the object and implements the Constant interface.
	Tank.Direction dir = Tank.Direction.R;//Initialize the direction of the tank to the right

	private boolean live = true;
	private boolean good;

	public boolean isGood() { //Judge the enemy or us
		return good;
	}

	public boolean isLive() {//Determine if the tank is alive
		return live;
	}

	public Bullet(int x, int y, Tank.Direction dir) {
		super(x, y);
		this.dir = dir;
	}

	public Bullet(int x, int y, Tank.Direction dir,boolean good,TankClient tc) {
	    super(x, y);
		this.dir = dir;
		this.good = good;   //The good attribute of tank is consistent with the good attribute of shell.
		this.tc = tc;
	}

	public void draw(Graphics g) {//This is how to draw bullets
		if(!this.live) {  // if the shell is dead, remove it from the container and return, instead of drawing it.
			tc.bullets.remove(this);//tc.bullets is one removed from the Tankclient container.
			return;//End
		}
		Color c = g.getColor();//Draw color
		if(!this.isGood()) //If it's ours, it's this color
			g.setColor(new Color(160,160,160));
		else//Otherwise it's blue
			g.setColor(Color.BLUE);
		g.fillOval(x, y, BulletWidth, BulletHeight);//Width and height from the parameters in the interface
		g.setColor(c);//Set color
		move();//Call the following move method
	}

	public void move() {
		switch(dir) { //Select with switch
		case L:       //Determine the direction of the bullet, plus or minus the X and y axes, respectively
			x -= BulletVx;
			break;
		case LU:
			x -= BulletVx;
			y -= BulletVy;
			break;
		case LD:
			x -= BulletVx;
			y += BulletVy;
			break;
		case R:
			x += BulletVx;
			break;
		case RU:
			x += BulletVx;
			y -= BulletVy;
			break;
		case RD:
			x += BulletVx;
			y += BulletVy;
			break;
		case U:
			y -= BulletVy;
			break;
		case D:
			y += BulletVy;
			break;
		}

		if(x < 0 || y < 30 || x >tc.ScreenWide-10 || y>tc.ScreenHeight-10) {
			this.live = false;	// if the shell goes out, it dies
		}

	}

	public Rectangle getRec() {
		return new Rectangle(x,y,BulletWidth,BulletHeight);//Import a shape class with width and height parameters from the interface
	}

	public boolean fireTanks(Tank t) {//This class is the enemy or us firing bullets
		if(this.getRec().intersects(t.getRec()) && t.isLive()  //Determine if the bullet hit our or enemy tank
				&& this.good!=t.isGood()) {
			t.setLive(false);
			this.live = false;  //Tank is dead
			Explode e = new Explode(x,y,this.tc); //Create an explosion class that will explode when hit
			e.setLive(true); //The explosion effect is displayed
			tc.explodes.add(e); //Add explodes type pairs to it
			return true;//Returns true if hit
		}
		return false;//If not hit returns flase
	}

	public boolean fireTank(List<Tank> tanks) {
		for(int i=0;i<tanks.size();i++) {
			if(fireTanks(tanks.get(i)))//Call the firetanks method above. The object passed in is List <Tank>.
				return true;//If the above method returns true, this method also returns true
		}
		return false;//Otherwise returns false

	}



}
