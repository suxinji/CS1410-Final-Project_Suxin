/**
 * @author Suxin Ji
 *
 */
public interface Constant {
	// This is an unmodifiable constant, so I put it in the interface.
	//The constants in the interface are public static final by default and must have these three keywords. 
	//You can write or not. My purpose is to remind myself. These quantities are immutable and static.
	public static final int TankVx = 4;
	public static final int TankVy = 4;
	public static final int BulletVx = 3;
	public static final int BulletVy = 3;
	public static final int ScreenWidth = 700;
	public static final int ScreenHeigh = 500;
	public static final int Width = 25;
	public static final int	Height = 25;
	public static final int BulletWidth = 15;
	public static final int BulletHeight = 15;


}
