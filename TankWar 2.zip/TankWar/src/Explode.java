/**
 * @author Suxin Ji
 *
 */
import java.awt.Color;
import java.awt.Graphics;

public class Explode extends Object {

	private boolean live = false;//Give it an initial value
	int [] diameter = {4,8,12,22,34,32,20,13,6};//Create an array
	int step = 0;//Create a variable

	public boolean isLive() {//Determine if the tank is still alive
		return live;
	}

	public void setLive(boolean live) {
		this.live = live;
	}

	public Explode(int x,int y,TankClient tc) { //This is a constructor
		super(x, y);
		this.tc = tc;
	}

	public void draw(Graphics g) {//Draw explode
		if(!this.live) {	//Make a judgment, if it has exploded, remove this object
			tc.explodes.remove(this);
			return;
		}

		if(step == diameter.length) {
			step = 0;
			this.live = false;//When the explosion disappears
			tc.explodes.remove(this);//Remove this object from explodes
		}
		Color c = g.getColor();
		g.setColor(Color.WHITE);//Set the color of the explosion
		g.fillOval(x, y, diameter[step], diameter[step]);//Coordinates, size, where, and how big the padding is.
		g.setColor(c);
		step++;
	}

}
