/**
 * @author Suxin Ji
 *
 */
import java.security.SecureRandom;
//This is a super class.
public class Object {

	protected int x;//x, y are coordinates
	protected int y;
	protected TankClient tc;
	//To introduce an object of the tank type, create the variable tc, and then use it to inherit its subclasses.
	//The subclasses can directly call the properties in it. All subclasses use the type Tankclient.
	//So I mentioned it in the parent class, in order to simplify the code
	protected static SecureRandom random = new SecureRandom();
	//To randomly generate coordinates
	//Why do I use protected? Because I add and call for subclasses

	public Object(int x, int y) {
		this.x = x;
		this.y = y;
	}
	//This is the parent class constructor.

	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}


}
