/**
 * @author Suxin Ji
 *
 */
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class TankClient extends Frame{

	public final int ScreenWide = 700;
	public final int ScreenHeight = 500;
	SecureRandom random = new SecureRandom();
	Tank myTank = new Tank(random.nextInt(400)+100,random.nextInt(400)+100,true,this);
	// a new tank came out, the third parameter is our tank or the enemy tank.

	Bullet bullet = null;
	Image screenImage = null;
	List<Bullet> bullets  = new ArrayList<Bullet> (); // this container holds the shell. Every shell fired by any tank is put into this container. When the shell hits the other tank or the shell is out of bounds, the shell is removed from the container.
	List<Explode> explodes = new ArrayList<Explode> ();
	List<Tank> tanks = new ArrayList<Tank> ();
 e
	public void update(Graphics g) {
		if(screenImage == null)
			screenImage = this.createImage(ScreenWide,ScreenHeight);
		Graphics graphics = screenImage.getGraphics();
		Color c = graphics.getColor();
		graphics.setColor(new Color(0,153,0));
		graphics.fillRect(0, 0, ScreenWide, ScreenHeight);
		graphics.setColor(c);
		paint(graphics);
		g.drawImage(screenImage, 0, 0, null);

	}
	public void paint(Graphics g) {//After the paint method is called, it will automatically call update
		g.drawString("Tanks  Counts: "+tanks.size(), 30, 90);
		myTank.draw(g);
		for(int i=0;i<bullets.size();i++) {
			Bullet b = bullets.get(i);
			// take all shells out of the container and call the hitTank method to determine if there is a concentrated tank. If hit, both the shell and the tank hit will be removed from the corresponding container.
		    b.fireTank(tanks);
		    b.fireTanks(myTank);  // the enemy can hit us.
			b.draw(g);     // draw out each shell

		}
	    for(int i= 0;i<explodes.size();i++) {
	    	Explode e = explodes.get(i);
	    	e.draw(g);
	    }
	    for(int i=0;i<tanks.size();i++) {
	    	Tank t = tanks.get(i);   // draw the remaining tanks out of the container.
	    	t.draw(g);
	    }


	}

	class PaintThread implements Runnable {

		public void run() {
			 while(true) {
				 try {
					repaint();  // redraw in this thread.Call repaint every once in a while, and repaint calls updata, and updata calls the paint method.
					Thread.sleep(100);// this time determines the speed of all objects.
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			 }
		}
	}

	public static void main(String[] args) {
		 TankClient tankclient = new TankClient();
		 tankclient.launch();

	}

	public void launch() {
		this.setResizable(false);
		this.setTitle("Super Tank War");
		this.setBackground(new Color(150,240,215));
		setLocation(random.nextInt(400),random.nextInt(400));
		setSize(ScreenWide,ScreenHeight);
		setVisible(true);
		this.addWindowListener(new MonitorWindow());//Join the window to listen for events.
		this.addKeyListener(new KeyMonitor());//Keyboard listen event
		new Thread(new PaintThread()).start();//Start thread

		for(int i=0; i<3;i++) {   //new 10 enemy tanks in container.
			Tank t = new Tank(50+40*(i+1),80+i,false,Tank.Direction.D,this);
			tanks.add(t);
		}
	}

	class KeyMonitor extends KeyAdapter {//Create a keyboard listener class
		public void keyReleased(KeyEvent e) {
		myTank.keyReleased(e);
		}
		// press or release this call to the tank class method for judgment processing.
		public void keyPressed(KeyEvent e) {
				myTank.KeyPress(e);

		}
	}

}

class MonitorWindow extends  WindowAdapter {//Create a MonitorWindow class, the role of this class is to close the window, the window listener class
	public void windowClosing(WindowEvent e) {
		System.exit(0);
	}

}
